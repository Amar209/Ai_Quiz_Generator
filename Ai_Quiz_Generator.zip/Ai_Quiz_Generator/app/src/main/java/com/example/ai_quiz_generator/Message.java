package com.example.ai_quiz_generator;

public class Message {
    private String role;
    private String content; // Ensure this field exists

    // Constructor
    public Message(String role, String content) {
        this.role = role;
        this.content = content;
    }

    // Must have this getter method
    public String getContent() {
        return content;
    }

    // Other getters/setters...
}