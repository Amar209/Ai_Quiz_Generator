package com.example.ai_quiz_generator;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ChatResponse {
    private String id;
    @SerializedName("object")
    private String object;
    private long created;
    private String model;
    private List<Choice> choices;
    private Usage usage;

    public List<Choice> getChoices() {
        return choices;
    }
}