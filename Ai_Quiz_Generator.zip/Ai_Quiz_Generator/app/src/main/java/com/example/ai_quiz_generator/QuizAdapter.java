package com.example.ai_quiz_generator;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.QuestionViewHolder> {

    private List<Question> questions;

    public QuizAdapter(List<Question> questions) {
        this.questions = questions;
    }

    public void updateQuestions(List<Question> newQuestions) {
        this.questions = newQuestions;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public QuestionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_question, parent, false);
        return new QuestionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QuestionViewHolder holder, int position) {
        holder.bind(questions.get(position));
    }

    @Override
    public int getItemCount() {
        return questions != null ? questions.size() : 0;
    }

    static class QuestionViewHolder extends RecyclerView.ViewHolder {
        private final TextView questionTextView;
        private final RadioGroup optionsRadioGroup;

        public QuestionViewHolder(View itemView) {
            super(itemView);
            questionTextView = itemView.findViewById(R.id.questionTextView);
            optionsRadioGroup = itemView.findViewById(R.id.optionsRadioGroup);
        }

        public void bind(Question question) {
            questionTextView.setText(question.getText());
            optionsRadioGroup.removeAllViews();

            for (int i = 0; i < question.getOptions().size(); i++) {
                Option option = question.getOptions().get(i);
                RadioButton radioButton = new RadioButton(itemView.getContext());
                radioButton.setText(String.format("%c) %s", 'A' + i, option.getText()));
                radioButton.setTag(option.isCorrect());
                optionsRadioGroup.addView(radioButton);
            }
        }
    }
}