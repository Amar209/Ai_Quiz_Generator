package com.example.ai_quiz_generator;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private QuizAdapter quizAdapter;
    private OpenAIApiService apiService;
    private ProgressBar progressBar;
    private RecyclerView quizRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupApiService();
        setupRecyclerView();
        setupGenerateButton();
    }

    private void initializeViews() {
        progressBar = findViewById(R.id.progressBar);
        quizRecyclerView = findViewById(R.id.quizRecyclerView);
    }

    private void setupApiService() {
        apiService = new Retrofit.Builder()
                .baseUrl("https://api.openai.com/v1/chat/completions")
                .client(createHttpClient())
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(OpenAIApiService.class);
    }

    private OkHttpClient createHttpClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        return new OkHttpClient.Builder()
                .addInterceptor(logging)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    private void setupRecyclerView() {
        quizRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        quizAdapter = new QuizAdapter(new ArrayList<>());
        quizRecyclerView.setAdapter(quizAdapter);
    }

    private void setupGenerateButton() {
        findViewById(R.id.generateButton).setOnClickListener(v -> {
            String prompt = ((android.widget.EditText) findViewById(R.id.promptEditText))
                    .getText().toString().trim();

            if (prompt.isEmpty()) {
                showToast("Please enter a prompt");
                return;
            }
            generateQuiz(prompt);
        });
    }

    private void generateQuiz(String prompt) {
        showLoading(true);

        ChatRequest request = new ChatRequest(
                "gpt-3.5-turbo",
                List.of(new Message("user", createPromptMessage(prompt))),
                0.7
        );

        apiService.generateContent(request, "Bearer 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")
                .enqueue(new Callback<ChatResponse>() {
                    @Override
                    public void onResponse(Call<ChatResponse> call, Response<ChatResponse> response) {
                        showLoading(false);
                        handleApiResponse(response);
                    }

                    @Override
                    public void onFailure(Call<ChatResponse> call, Throwable t) {
                        showLoading(false);
                        showToast("Network error: " + t.getMessage());
                    }
                });
    }

    private String createPromptMessage(String prompt) {
        return "Generate a quiz based on: " + prompt +
                ". Format each question with the question text followed by " +
                "4 options labeled A) to D) and indicate the correct answer " +
                "with '(Correct)' at the end of the option.";
    }

    private void handleApiResponse(Response<ChatResponse> response) {
        if (response.isSuccessful() && response.body() != null) {
            ChatResponse chatResponse = response.body();
            if (chatResponse.getChoices() != null && !chatResponse.getChoices().isEmpty()) {
                String quizContent = chatResponse.getChoices().get(0).getMessage().getContent();
                if (quizContent != null && !quizContent.isEmpty()) {
                    displayQuizQuestions(quizContent);
                    return;
                }
            }
            showToast("Failed to generate quiz content");
        } else {
            try {
                String error = response.errorBody() != null ?
                        response.errorBody().string() : "Unknown error";
                showToast("API Error: " + error);
            } catch (IOException e) {
                showToast("Error parsing response");
            }
        }
    }

    private void displayQuizQuestions(String quizContent) {
        List<Question> questions = parseQuizContent(quizContent);
        if (!questions.isEmpty()) {
            quizAdapter.updateQuestions(questions);
            quizRecyclerView.setVisibility(View.VISIBLE);
        } else {
            showToast("No valid questions found");
        }
    }

    private List<Question> parseQuizContent(String content) {
        List<Question> questions = new ArrayList<>();
        String[] questionBlocks = content.split("\n\n");

        for (String block : questionBlocks) {
            if (block.trim().isEmpty()) continue;

            String[] lines = block.split("\n");
            if (lines.length >= 5) { // 1 question + 4 options
                String questionText = lines[0].trim();
                List<Option> options = extractOptions(lines);

                if (options.size() >= 4) {
                    questions.add(new Question(questionText, options));
                }
            }
        }
        return questions;
    }

    private List<Option> extractOptions(String[] lines) {
        List<Option> options = new ArrayList<>();
        for (int i = 1; i < Math.min(5, lines.length); i++) {
            String optionText = lines[i].trim();
            boolean isCorrect = optionText.toLowerCase().contains("(correct)");
            String cleanOption = optionText.replace("(Correct)", "")
                    .replace("(correct)", "")
                    .trim();
            options.add(new Option(cleanOption, isCorrect));
        }
        return options;
    }

    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        quizRecyclerView.setVisibility(isLoading ? View.GONE : View.VISIBLE);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}