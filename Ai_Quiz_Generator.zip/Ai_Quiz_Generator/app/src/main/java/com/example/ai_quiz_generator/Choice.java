package com.example.ai_quiz_generator;

public class Choice {
    private int index;
    private Message message;
    private String finish_reason;

    public Message getMessage() {
        return message;
    }
}